export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number; // index
  explanation: string;
  source: string;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  icon: string;
  theory: string; // Markdown-like or plain text
  questions: Question[];
  system: string;
}

export interface UserProgress {
  xp: number;
  hearts: number;
  completedLessons: string[]; // IDs of completed lessons
  streak: number;
  lastLoginDate: string;
  darkMode: boolean;
  userName: string;
  defaultTrack: Track;
}

export type Tab = 'learn' | 'library' | 'settings';
export type Track = 'biossistemas' | 'processos';

export interface AppState {
  currentTab: Tab;
  currentTrack: Track;
  activeLessonId: string | null;
  lessonMode: 'theory' | 'quiz' | null; // null if not in a lesson
}