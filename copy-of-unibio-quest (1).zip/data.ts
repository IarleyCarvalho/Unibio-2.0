import { Lesson } from './types';

export const biossistemasData: Lesson[] = [
  {
    id: 'bio-cardio',
    system: 'Sistema Cardiovascular',
    title: 'O Motor da Vida',
    description: 'Ciclo cardíaco e vasos sanguíneos',
    icon: '❤️',
    theory: `### Sistema Cardiovascular

**Função:** Transporte de sangue.

**Ciclo Cardíaco:**
*   **Sístole:** Contração (Ejeção de sangue).
*   **Diástole:** Relaxamento (Enchimento).

**Estruturas:**
*   **Ventrículo Esquerdo:** Parede espessa para bombear sangue oxigenado para todo o corpo (circulação sistêmica).
*   **Nó Sinoatrial:** O "marca-passo" natural que inicia o impulso elétrico.
*   **Veias:** Possuem **válvulas** para impedir o refluxo do sangue.
*   **Capilares:** Local de **trocas gasosas** e nutrientes.`,
    questions: [
      { id: 'q-card-1', text: 'Qual a função das válvulas nas veias?', options: ['Aumentar pressão', 'Impedir refluxo', 'Oxigenar', 'Filtrar'], correctAnswer: 1, explanation: 'Garantem fluxo unidirecional.', source: 'Guyton' },
      { id: 'q-card-2', text: 'O que ocorre na Sístole?', options: ['Relaxamento', 'Enchimento', 'Contração/Ejeção', 'Parada'], correctAnswer: 2, explanation: 'Sístole é a fase de contração.', source: 'Tortora' },
      { id: 'q-card-3', text: 'Qual câmara bombeia sangue para o corpo (sistêmica)?', options: ['Átrio Dir.', 'Ventrículo Dir.', 'Átrio Esq.', 'Ventrículo Esq.'], correctAnswer: 3, explanation: 'O ventrículo esquerdo tem a parede mais grossa.', source: 'Netter' },
      { id: 'q-card-4', text: 'Onde ocorrem as trocas gasosas?', options: ['Artérias', 'Veias', 'Capilares', 'Aorta'], correctAnswer: 2, explanation: 'Nos capilares, devido à parede fina.', source: 'Junqueira' },
      { id: 'q-card-5', text: 'Quem é o marca-passo natural do coração?', options: ['Nó Sinoatrial', 'His', 'Purkinje', 'AV'], correctAnswer: 0, explanation: 'Inicia o impulso elétrico.', source: 'Guyton' }
    ]
  },
  {
    id: 'bio-respi',
    system: 'Sistema Respiratório',
    title: 'Respire Fundo',
    description: 'Ventilação e Hematose',
    icon: '🫁',
    theory: `### Sistema Respiratório

**Ventilação:**
*   **Inspiração:** O **Diafragma** contrai e desce, pressão interna diminui (fica negativa em relação à atmosférica), ar entra.
*   **Expiração:** Relaxamento.

**Hematose:** Troca de gases (O2 entra, CO2 sai) que ocorre nos **Alvéolos Pulmonares**.
**Transporte:** O oxigênio viaja no sangue ligado à **Hemoglobina**.
**Proteção:** A **Epiglote** fecha a glote ao engolir para proteger a via aérea.`,
    questions: [
      { id: 'q-resp-1', text: 'Onde ocorre a Hematose?', options: ['Traqueia', 'Brônquios', 'Alvéolos', 'Laringe'], correctAnswer: 2, explanation: 'Nos alvéolos pulmonares.', source: 'Tortora' },
      { id: 'q-resp-2', text: 'Principal músculo da inspiração?', options: ['Intercostal', 'Diafragma', 'Escaleno', 'Reto abdominal'], correctAnswer: 1, explanation: 'O diafragma realiza a maior parte do trabalho.', source: 'Moore' },
      { id: 'q-resp-3', text: 'Como o oxigênio é transportado?', options: ['Dissolvido', 'Ligado à Hemoglobina', 'Como CO2', 'Livre'], correctAnswer: 1, explanation: 'Ligado ao ferro da hemoglobina.', source: 'Guyton' },
      { id: 'q-resp-4', text: 'Na inspiração, a pressão intrapulmonar:', options: ['Aumenta', 'Fica positiva', 'Diminui (negativa)', 'Não muda'], correctAnswer: 2, explanation: 'Torna-se menor que a atmosférica.', source: 'Silverthorn' },
      { id: 'q-resp-5', text: 'Qual estrutura impede alimento na traqueia?', options: ['Úvula', 'Epiglote', 'Tireoide', 'Língua'], correctAnswer: 1, explanation: 'Fecha a laringe durante a deglutição.', source: 'Netter' }
    ]
  },
  {
    id: 'bio-renal',
    system: 'Sistema Renal',
    title: 'Filtragem',
    description: 'Néfron e Urina',
    icon: '💧',
    theory: `### Sistema Renal

**Néfron:** Unidade funcional do rim.
**Processo:** O sangue é filtrado no **Glomérulo**.
**Reabsorção:**
*   **Glicose:** 100% reabsorvida no Túbulo Proximal (não deve ter glicose na urina saudável).
*   **Água:** Maior parte reabsorvida no Túbulo Proximal.
**Hormônios:**
*   **ADH (Antidiurético):** Aumenta reabsorção de água (concentra urina).`,
    questions: [
      { id: 'q-ren-1', text: 'Unidade funcional do rim?', options: ['Cálice', 'Néfron', 'Ureter', 'Bexiga'], correctAnswer: 1, explanation: 'O néfron realiza a filtração.', source: 'Junqueira' },
      { id: 'q-ren-2', text: 'Onde ocorre a filtração do sangue?', options: ['Túbulo Distal', 'Glomérulo', 'Alça de Henle', 'Coletor'], correctAnswer: 1, explanation: 'No tufo de capilares glomerulares.', source: 'Netter' },
      { id: 'q-ren-3', text: 'Substância ausente na urina saudável?', options: ['Ureia', 'Sódio', 'Glicose', 'Creatinina'], correctAnswer: 2, explanation: 'É totalmente reabsorvida.', source: 'Guyton' },
      { id: 'q-ren-4', text: 'Função do ADH?', options: ['Eliminar sódio', 'Reabsorver água', 'Dilatar vasos', 'Filtrar proteínas'], correctAnswer: 1, explanation: 'Retém água no corpo.', source: 'Tortora' },
      { id: 'q-ren-5', text: 'Onde ocorre maior reabsorção de água?', options: ['Túbulo Proximal', 'Distal', 'Henle', 'Coletor'], correctAnswer: 0, explanation: 'Aproximadamente 65% é reabsorvida logo no início.', source: 'Silverthorn' }
    ]
  },
  {
    id: 'bio-digest',
    system: 'Sistema Digestório',
    title: 'Digestão',
    description: 'Enzimas e Absorção',
    icon: '🍎',
    theory: `### Sistema Digestório

**Boca:** **Amilase Salivar** digere amido.
**Estômago:** pH ácido (**HCl**) ativa a **Pepsina** (digere proteínas).
**Fígado:** Produz **Bile** (emulsifica gorduras), armazenada na **Vesícula Biliar**.
**Intestino Delgado:** Possui **Vilosidades** para maximizar a absorção.
**Intestino Grosso:** Principal local de absorção de **água** final e formação de fezes.`,
    questions: [
      { id: 'q-dig-1', text: 'Enzima da boca que digere amido?', options: ['Pepsina', 'Lipase', 'Amilase Salivar', 'Tripsina'], correctAnswer: 2, explanation: 'Inicia digestão de carboidratos.', source: 'Tortora' },
      { id: 'q-dig-2', text: 'O que torna o estômago ácido?', options: ['Bicarbonato', 'Ácido Clorídrico (HCl)', 'Bile', 'Mucina'], correctAnswer: 1, explanation: 'Secretado pelas células parietais.', source: 'Guyton' },
      { id: 'q-dig-3', text: 'Quem produz a bile?', options: ['Fígado', 'Vesícula', 'Pâncreas', 'Duodeno'], correctAnswer: 0, explanation: 'Produzida no fígado, armazenada na vesícula.', source: 'Moore' },
      { id: 'q-dig-4', text: 'Função das vilosidades?', options: ['Produzir ácido', 'Aumentar absorção', 'Triturar', 'Proteger'], correctAnswer: 1, explanation: 'Aumentam a superfície de contato.', source: 'Junqueira' },
      { id: 'q-dig-5', text: 'Onde ocorre absorção final de água?', options: ['Estômago', 'Delgado', 'Grosso', 'Esôfago'], correctAnswer: 2, explanation: 'Compacta o bolo fecal.', source: 'Silverthorn' }
    ]
  },
  {
    id: 'bio-endo',
    system: 'Sistema Endócrino',
    title: 'Hormônios',
    description: 'Regulação Química',
    icon: '⚡',
    theory: `### Sistema Endócrino

**Hipófise:** Glândula "Mestra".
**Pâncreas:**
*   **Insulina:** Reduz glicose no sangue (entra na célula).
*   **Glucagon:** Aumenta glicose no sangue.
**Tireoide:** Produz **T3 e T4** (controlam metabolismo).
**Adrenais:**
*   **Adrenalina:** Luta ou fuga.
*   **Cortisol:** Estresse e controle de glicemia.`,
    questions: [
      { id: 'q-end-1', text: 'Hormônio que reduz glicose no sangue?', options: ['Glucagon', 'Cortisol', 'Insulina', 'Adrenalina'], correctAnswer: 2, explanation: 'Promove entrada de glicose nas células.', source: 'Guyton' },
      { id: 'q-end-2', text: 'Glândula "mestra"?', options: ['Tireoide', 'Hipófise', 'Pineal', 'Suprarenal'], correctAnswer: 1, explanation: 'Comanda outras glândulas.', source: 'Tortora' },
      { id: 'q-end-3', text: 'T3 e T4 são de qual glândula?', options: ['Paratireoide', 'Tireoide', 'Timo', 'Pâncreas'], correctAnswer: 1, explanation: 'Regulam metabolismo basal.', source: 'Silverthorn' },
      { id: 'q-end-4', text: 'Hormônio de "luta ou fuga"?', options: ['Melatonina', 'Ocitocina', 'Adrenalina', 'Prolactina'], correctAnswer: 2, explanation: 'Prepara o corpo para ação rápida.', source: 'Guyton' },
      { id: 'q-end-5', text: 'Cortisol está ligado a:', options: ['Estresse', 'Reprodução', 'Crescimento', 'Sono'], correctAnswer: 0, explanation: 'Hormônio do estresse.', source: 'Berne' }
    ]
  },
  {
    id: 'bio-teg',
    system: 'Sistema Tegumentar',
    title: 'Pele',
    description: 'Proteção e Tato',
    icon: '🛡️',
    theory: `### Sistema Tegumentar

**Epiderme:** Camada externa. Possui **Queratina** (impermeabilizante) e **Melanócitos** (Melanina/cor).
**Derme:** Tecido conjuntivo abaixo.
**Células de Merkel:** Receptores de tato leve localizados na epiderme basal.
**Glândulas Sudoríparas:** Produzem suor para **Termorregulação** (resfriar).`,
    questions: [
      { id: 'q-teg-1', text: 'Proteína que impermeabiliza a pele?', options: ['Colágeno', 'Elastina', 'Queratina', 'Actina'], correctAnswer: 2, explanation: 'Evita perda de água.', source: 'Junqueira' },
      { id: 'q-teg-2', text: 'Função das Células de Merkel?', options: ['Produzir cor', 'Tato leve', 'Imunidade', 'Produzir suor'], correctAnswer: 1, explanation: 'Mecanorreceptores cutâneos.', source: 'Junqueira' },
      { id: 'q-teg-3', text: 'Onde estão os melanócitos?', options: ['Epiderme', 'Derme', 'Hipoderme', 'Músculo'], correctAnswer: 0, explanation: 'Na camada basal da epiderme.', source: 'Junqueira' },
      { id: 'q-teg-4', text: 'Tecido da Derme?', options: ['Epitelial', 'Conjuntivo', 'Nervoso', 'Adiposo'], correctAnswer: 1, explanation: 'Rico em colágeno e vasos.', source: 'Junqueira' },
      { id: 'q-teg-5', text: 'Função do suor?', options: ['Lubrificar', 'Termorregulação', 'Nutrir', 'Sintetizar Vit D'], correctAnswer: 1, explanation: 'Evaporação resfria o corpo.', source: 'Guyton' }
    ]
  },
  {
    id: 'bio-linf',
    system: 'Sistema Linfático',
    title: 'Imunidade',
    description: 'Filtros e Defesa',
    icon: '🦠',
    theory: `### Sistema Linfático

**Linfa:** Líquido similar ao plasma.
**Linfonodos:** Estruturas que **filtram a linfa** e ativam linfócitos.
**Baço:** Filtra o **sangue** (remove hemácias velhas).
**Timo:** Local de maturação dos **Linfócitos T**.
**Função:** Drenagem de excesso de líquido (evita **Edema**).`,
    questions: [
      { id: 'q-lin-1', text: 'Quem filtra o sangue?', options: ['Linfonodo', 'Baço', 'Timo', 'Amígdala'], correctAnswer: 1, explanation: 'Remove células velhas do sangue.', source: 'Moore' },
      { id: 'q-lin-2', text: 'Maturação de Linfócitos T?', options: ['Medula', 'Timo', 'Baço', 'Sangue'], correctAnswer: 1, explanation: 'T de Timo.', source: 'Abbas' },
      { id: 'q-lin-3', text: 'Função dos linfonodos?', options: ['Bombear', 'Filtrar linfa', 'Produzir hemácias', 'Digerir'], correctAnswer: 1, explanation: 'Retêm patógenos da linfa.', source: 'Tortora' },
      { id: 'q-lin-4', text: 'O que circula nos vasos linfáticos?', options: ['Sangue', 'Ar', 'Linfa', 'Bile'], correctAnswer: 2, explanation: 'Fluido intersticial recolhido.', source: 'Guyton' },
      { id: 'q-lin-5', text: 'A falha na drenagem linfática causa:', options: ['Gordura', 'Edema (Inchaço)', 'Hipertrofia', 'Febre'], correctAnswer: 1, explanation: 'Acúmulo de líquido.', source: 'Moore' }
    ]
  },
  {
    id: 'bio-snc',
    system: 'S. Nervoso Central',
    title: 'Comando',
    description: 'Encéfalo e Medula',
    icon: '🧠',
    theory: `### S.N. Central

**Cerebelo:** Equilíbrio e coordenação motora fina.
**Bulbo (Tronco):** Controle vital (respiração/coração).
**Meninges:** Membranas protetoras. A **Dura-máter** é a mais externa e resistente.
**Líquor:** Circula no espaço **Subaracnoide**.
**Substância Cinzenta:** Corpos de neurônios.`,
    questions: [
      { id: 'q-snc-1', text: 'Controla equilíbrio e coordenação?', options: ['Cérebro', 'Cerebelo', 'Bulbo', 'Hipotálamo'], correctAnswer: 1, explanation: 'Ajuste fino motor.', source: 'Machado' },
      { id: 'q-snc-2', text: 'Meninge mais externa?', options: ['Pia-máter', 'Aracnoide', 'Dura-máter', 'Corioide'], correctAnswer: 2, explanation: 'Espessa e resistente.', source: 'Machado' },
      { id: 'q-snc-3', text: 'Centro respiratório?', options: ['Córtex', 'Bulbo', 'Cerebelo', 'Tálamo'], correctAnswer: 1, explanation: 'Controle vegetativo vital.', source: 'Guyton' },
      { id: 'q-snc-4', text: 'O que forma a substância cinzenta?', options: ['Axônios', 'Corpos celulares', 'Gordura', 'Vasos'], correctAnswer: 1, explanation: 'Corpos de neurônios.', source: 'Machado' },
      { id: 'q-snc-5', text: 'Onde circula o líquor?', options: ['Epidural', 'Subdural', 'Subaracnoide', 'Intra-axonal'], correctAnswer: 2, explanation: 'Entre aracnoide e pia-máter.', source: 'Machado' }
    ]
  },
  {
    id: 'bio-snp',
    system: 'S. Nervoso Periférico',
    title: 'Conexões',
    description: 'Nervos e Autônomo',
    icon: '🔗',
    theory: `### S.N. Periférico

**Nervos Cranianos:** 12 pares. O **Vago (X)** é o principal do parassimpático.
**Simpático:** "Luta ou Fuga". Dilata pupila (**Midríase**).
**Parassimpático:** "Repouso". Usa **Acetilcolina**.
**Gânglios Sensitivos:** Localizados na **Raiz Dorsal** da medula.`,
    questions: [
      { id: 'q-snp-1', text: 'Quantos pares de nervos cranianos?', options: ['10', '12', '31', '33'], correctAnswer: 1, explanation: 'São 12 pares.', source: 'Machado' },
      { id: 'q-snp-2', text: 'Efeito do Simpático na pupila?', options: ['Miose (contrai)', 'Bradicardia', 'Midríase (dilata)', 'Nenhum'], correctAnswer: 2, explanation: 'Melhora visão para perigo.', source: 'Guyton' },
      { id: 'q-snp-3', text: 'Nervo Vago (X) pertence a qual sistema?', options: ['Simpático', 'Parassimpático', 'Somático', 'Motor'], correctAnswer: 1, explanation: 'Principal efetor parassimpático.', source: 'Machado' },
      { id: 'q-snp-4', text: 'Onde estão gânglios sensitivos?', options: ['Cérebro', 'Raiz Dorsal', 'Músculo', 'Ventrículo'], correctAnswer: 1, explanation: 'Entrada sensorial na medula.', source: 'Machado' },
      { id: 'q-snp-5', text: 'Neurotransmissor parassimpático?', options: ['Adrenalina', 'Acetilcolina', 'Dopamina', 'GABA'], correctAnswer: 1, explanation: 'Principal mediador colinérgico.', source: 'Guyton' }
    ]
  },
  {
    id: 'bio-sen',
    system: 'Sistema Sensorial',
    title: 'Sentidos',
    description: 'Percepção',
    icon: '👁️',
    theory: `### Sentidos

**Visão:** **Cones** (Cores), Bastonetes (Luz fraca).
**Audição:** Receptores na **Cóclea** (Órgão de Corti).
**Equilíbrio:** **Vestíbulo** e Canais Semicirculares.
**Olfato:** Único sentido que **não passa pelo Tálamo** antes do córtex.
**Tato Fino:** Corpúsculos de **Meissner**.`,
    questions: [
      { id: 'q-sen-1', text: 'Células que detectam cores?', options: ['Bastonetes', 'Cones', 'Bipolares', 'Amácrinas'], correctAnswer: 1, explanation: 'Cones = Cores.', source: 'Guyton' },
      { id: 'q-sen-2', text: 'Onde estão receptores auditivos?', options: ['Tímpano', 'Ossículos', 'Cóclea', 'Canal'], correctAnswer: 2, explanation: 'Na cóclea.', source: 'Silverthorn' },
      { id: 'q-sen-3', text: 'Equilíbrio é detectado por:', options: ['Cóclea', 'Vestíbulo', 'Tímpano', 'Martelo'], correctAnswer: 1, explanation: 'Aparelho vestibular.', source: 'Tortora' },
      { id: 'q-sen-4', text: 'Sentido que não passa pelo tálamo?', options: ['Visão', 'Audição', 'Olfato', 'Tato'], correctAnswer: 2, explanation: 'Vai direto ao córtex olfatório.', source: 'Machado' },
      { id: 'q-sen-5', text: 'Tato fino é detectado por:', options: ['Meissner', 'Terminação livre', 'Pacini', 'Merkel'], correctAnswer: 0, explanation: 'Corpúsculos de Meissner.', source: 'Junqueira' }
    ]
  },
  {
    id: 'bio-esq',
    system: 'Sistema Esquelético',
    title: 'Ossos',
    description: 'Suporte',
    icon: '💀',
    theory: `### Esquelético

**Células:**
*   **Osteoclasto:** Reabsorve ("come") osso.
*   **Osteoblasto:** Produz osso.
**Medula Óssea Vermelha:** Faz hematopoese (sangue).
**Classificação:** Fêmur é osso **Longo**.
**Unidade:** O **Ósteon** (Sistema de Havers) no osso compacto.`,
    questions: [
      { id: 'q-esq-1', text: 'Célula que reabsorve osso?', options: ['Osteócito', 'Osteoblasto', 'Osteoclasto', 'Condrócito'], correctAnswer: 2, explanation: 'Degrada matriz óssea.', source: 'Junqueira' },
      { id: 'q-esq-2', text: 'Onde produz sangue?', options: ['Medula Amarela', 'Medula Vermelha', 'Periósteo', 'Cartilagem'], correctAnswer: 1, explanation: 'Hematopoese.', source: 'Junqueira' },
      { id: 'q-esq-3', text: 'Fêmur é osso:', options: ['Curto', 'Longo', 'Plano', 'Irregular'], correctAnswer: 1, explanation: 'Comprimento predomina.', source: 'Moore' },
      { id: 'q-esq-4', text: 'Articulação do ombro é:', options: ['Sutura', 'Sinovial', 'Fibrosa', 'Imóvel'], correctAnswer: 1, explanation: 'Grande mobilidade.', source: 'Moore' },
      { id: 'q-esq-5', text: 'Unidade do osso compacto?', options: ['Trabécula', 'Ósteon', 'Volkmann', 'Lacuna'], correctAnswer: 1, explanation: 'Sistema de Havers.', source: 'Junqueira' }
    ]
  },
  {
    id: 'bio-mus',
    system: 'Sistema Muscular',
    title: 'Músculos',
    description: 'Contração',
    icon: '💪',
    theory: `### Muscular

**Sarcômero:** Unidade contrátil entre duas linhas Z. Contém **Actina** (fina) e **Miosina** (grossa).
**Contração:** Depende de **Cálcio** (libera sítio na actina).
**Tipos:**
*   **Liso:** Involuntário, nas vísceras (intestino).
*   **Fibras Tipo I:** Lentas, vermelhas, resistentes.`,
    questions: [
      { id: 'q-mus-1', text: 'Íon essencial para contração?', options: ['Sódio', 'Potássio', 'Cálcio', 'Cloro'], correctAnswer: 2, explanation: 'Liga-se à troponina.', source: 'Guyton' },
      { id: 'q-mus-2', text: 'Unidade contrátil?', options: ['Miofibrila', 'Sarcômero', 'Sarcolema', 'Túbulo T'], correctAnswer: 1, explanation: 'Segmento funcional.', source: 'Tortora' },
      { id: 'q-mus-3', text: 'Músculo do intestino?', options: ['Estriado', 'Cardíaco', 'Liso', 'Esquelético'], correctAnswer: 2, explanation: 'Involuntário visceral.', source: 'Junqueira' },
      { id: 'q-mus-4', text: 'Fibras Tipo I são:', options: ['Rápidas', 'Lentas/Vermelhas', 'Brancas', 'Anaeróbicas'], correctAnswer: 1, explanation: 'Resistentes à fadiga.', source: 'McArdle' },
      { id: 'q-mus-5', text: 'Proteína grossa?', options: ['Actina', 'Miosina', 'Troponina', 'Titina'], correctAnswer: 1, explanation: 'Filamento espesso.', source: 'Guyton' }
    ]
  },
  {
    id: 'bio-imu',
    system: 'Sistema Imunitário',
    title: 'Defesa',
    description: 'Guerra Celular',
    icon: '🛡️',
    theory: `### Imunitário

**Células:**
*   **Linfócitos B:** Viram **Plasmócitos** e produzem **Anticorpos**.
*   **Macrófagos/Neutrófilos:** Fazem **fagocitose**.
**Imunoglobulinas:** **IgG** é a mais abundante no sangue.
**Vacina:** Imunidade **Ativa Artificial** (ensina o corpo).
**Inflamação:** Dor, Calor, Rubor, Edema.`,
    questions: [
      { id: 'q-imu-1', text: 'Quem produz anticorpos?', options: ['T CD4', 'Macrófago', 'Plasmócito (B)', 'NK'], correctAnswer: 2, explanation: 'Fábrica de anticorpos.', source: 'Abbas' },
      { id: 'q-imu-2', text: 'Vacinação é imunidade:', options: ['Passiva', 'Ativa Artificial', 'Passiva Artificial', 'Natural'], correctAnswer: 1, explanation: 'Estimula memória.', source: 'Abbas' },
      { id: 'q-imu-3', text: 'Imunoglobulina mais abundante?', options: ['IgM', 'IgA', 'IgG', 'IgE'], correctAnswer: 2, explanation: 'Principal no sangue.', source: 'Abbas' },
      { id: 'q-imu-4', text: 'Sinais da inflamação?', options: ['Dor, Calor, Rubor, Edema', 'Frio, Secura', 'Necrose', 'Apoptose'], correctAnswer: 0, explanation: 'Sinais cardinais.', source: 'Robbins' },
      { id: 'q-imu-5', text: 'Quem faz fagocitose?', options: ['Hemácia', 'Macrófago', 'Plaqueta', 'Linfócito B'], correctAnswer: 1, explanation: 'Come patógenos.', source: 'Junqueira' }
    ]
  },
  {
    id: 'bio-rep-mas',
    system: 'Reprodutor Masc.',
    title: 'Masculino',
    description: 'Gametas',
    icon: '♂️',
    theory: `### Reprodutor Masc.

**Testículos:**
*   **Túbulos Seminíferos:** Produzem espermatozoides (estimulado por **FSH**).
*   **Células de Leydig:** Produzem **Testosterona** (estimulado por LH).
**Epidídimo:** Armazena e matura espermatozoides.
**Próstata:** Secreta fluido **alcalino** (proteção contra acidez vaginal).`,
    questions: [
      { id: 'q-rm-1', text: 'Onde produz espermatozoides?', options: ['Epidídimo', 'Próstata', 'Túbulos Seminíferos', 'Vesícula'], correctAnswer: 2, explanation: 'Fábrica de gametas.', source: 'Moore' },
      { id: 'q-rm-2', text: 'Onde maturam os espermatozoides?', options: ['Epidídimo', 'Deferente', 'Uretra', 'Próstata'], correctAnswer: 0, explanation: 'Ganham mobilidade.', source: 'Moore' },
      { id: 'q-rm-3', text: 'Quem produz Testosterona?', options: ['Sertoli', 'Leydig', 'Germinativas', 'Mioides'], correctAnswer: 1, explanation: 'Intersticiais.', source: 'Guyton' },
      { id: 'q-rm-4', text: 'Fluido prostático é:', options: ['Ácido', 'Alcalino', 'Neutro', 'Gasoso'], correctAnswer: 1, explanation: 'Neutraliza acidez.', source: 'Tortora' },
      { id: 'q-rm-5', text: 'Hormônio da espermatogênese?', options: ['LH', 'FSH', 'Prolactina', 'TSH'], correctAnswer: 1, explanation: 'Atua em Sertoli.', source: 'Guyton' }
    ]
  },
  {
    id: 'bio-rep-fem',
    system: 'Reprodutor Fem.',
    title: 'Feminino',
    description: 'Ciclo',
    icon: '♀️',
    theory: `### Reprodutor Fem.

**Fertilização:** Ocorre na **Tuba Uterina**.
**Ovulação:** Causada pelo **Pico de LH**.
**Útero:** A camada interna (**Endométrio**) descama na menstruação.
**Corpo Lúteo:** Produz **Progesterona** para manter a gravidez inicial.
**Menopausa:** Fim dos folículos ovarianos.`,
    questions: [
      { id: 'q-rf-1', text: 'Onde ocorre fertilização?', options: ['Útero', 'Ovário', 'Tuba Uterina', 'Vagina'], correctAnswer: 2, explanation: 'Terço distal da tuba.', source: 'Moore' },
      { id: 'q-rf-2', text: 'O que causa ovulação?', options: ['FSH', 'Pico de LH', 'Estrogênio', 'Progesterona'], correctAnswer: 1, explanation: 'Rompimento folicular.', source: 'Guyton' },
      { id: 'q-rf-3', text: 'Camada que descama?', options: ['Miométrio', 'Perimétrio', 'Endométrio', 'Serosa'], correctAnswer: 2, explanation: 'Camada funcional.', source: 'Junqueira' },
      { id: 'q-rf-4', text: 'Corpo lúteo produz:', options: ['LH', 'FSH', 'Progesterona', 'Prolactina'], correctAnswer: 2, explanation: 'Mantém endométrio.', source: 'Guyton' },
      { id: 'q-rf-5', text: 'Causa da menopausa?', options: ['Falência Renal', 'Falência Ovariana', 'Útero', 'Tubas'], correctAnswer: 1, explanation: 'Fim dos óvulos.', source: 'Guyton' }
    ]
  }
];

export const processosData: Lesson[] = [
    {
    id: 'proc-cell',
    system: 'Biologia Celular',
    title: 'A Célula',
    description: 'Estrutura e Organelas',
    icon: '🧬',
    theory: `### A Célula

**Mitocôndria:** Respiração celular e produção de **ATP** (energia).
**Ribossomo:** Síntese de **Proteínas**.
**Núcleo:** Guarda o **DNA**.
**Lisossomo:** Digestão intracelular.
**Membrana Plasmática:** É **Permeável Seletiva** (escolhe o que entra).`,
    questions: [
         { id: 'q-proc-1', text: 'Quem produz ATP?', options: ['Golgi', 'Mitocôndria', 'Núcleo', 'Ribossomo'], correctAnswer: 1, explanation: 'Usina de energia.', source: 'Alberts' },
         { id: 'q-proc-2', text: 'Síntese de proteínas?', options: ['Lisossomo', 'Ribossomo', 'Centríolo', 'Vacúolo'], correctAnswer: 1, explanation: 'Lê o RNAm.', source: 'Alberts' },
         { id: 'q-proc-3', text: 'Onde fica o DNA?', options: ['Núcleo', 'Golgi', 'Retículo', 'Citoplasma'], correctAnswer: 0, explanation: 'Protegido no núcleo.', source: 'Alberts' },
         { id: 'q-proc-4', text: 'Digestão celular?', options: ['Lisossomo', 'Ribossomo', 'Peroxissomo', 'Cloroplasto'], correctAnswer: 0, explanation: 'Enzimas digestivas.', source: 'Alberts' },
         { id: 'q-proc-5', text: 'Membrana plasmática é:', options: ['Permeável', 'Impermeável', 'Permeável Seletiva', 'Rígida'], correctAnswer: 2, explanation: 'Controla fluxo.', source: 'Alberts' }
    ]
  }
];
