import React from 'react';
import { Lesson } from '../types';
import Button from './Button';
import { ArrowRight, X } from 'lucide-react';

interface StudyCardProps {
  lesson: Lesson;
  onComplete: () => void;
  onBack: () => void;
}

const StudyCard: React.FC<StudyCardProps> = ({ lesson, onComplete, onBack }) => {
  
  const renderContent = (text: string) => {
    return text.split('\n').map((line, index) => {
      if (line.startsWith('### ')) {
        return <h3 key={index} className="text-xl font-bold text-gray-800 dark:text-gray-100 mt-4 mb-2">{line.replace('### ', '')}</h3>;
      }
      if (line.startsWith('**') && line.endsWith('**')) { 
         return <p key={index} className="font-bold text-gray-700 dark:text-gray-300 my-2">{line.replace(/\*\*/g, '')}</p>;
      }
      if (line.startsWith('* ')) {
        return <li key={index} className="ml-4 text-gray-600 dark:text-gray-400 list-disc">{line.replace('* ', '')}</li>;
      }
      const parts = line.split(/(\*\*.*?\*\*)/g);
      return (
        <p key={index} className="text-gray-600 dark:text-gray-400 leading-relaxed mb-2">
            {parts.map((part, i) => {
                if (part.startsWith('**') && part.endsWith('**')) {
                    return <strong key={i} className="text-duo-green-dark dark:text-green-400">{part.replace(/\*\*/g, '')}</strong>
                }
                return part;
            })}
        </p>
      );
    });
  };

  return (
    <div className="flex flex-col h-full pt-16 pb-24 px-4 max-w-lg mx-auto w-full bg-white dark:bg-gray-900 transition-colors relative">
      
      {/* Back Button */}
      <div className="absolute top-20 left-4 z-20">
        <button 
          onClick={onBack}
          className="p-2 rounded-full text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300 transition-colors"
          aria-label="Voltar"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar pt-12">
        <div className="mb-6 text-center">
            <span className="text-6xl mb-4 block">{lesson.icon}</span>
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">{lesson.system}</h2>
            <p className="text-gray-500 dark:text-gray-400">{lesson.title}</p>
        </div>
        
        <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-2xl border-2 border-gray-100 dark:border-gray-700 transition-colors">
            {renderContent(lesson.theory)}
        </div>
      </div>

      <div className="mt-4">
        <Button fullWidth onClick={onComplete}>
            ENTENDI! VAMOS PRO QUIZ <ArrowRight className="inline ml-2 w-5 h-5" />
        </Button>
      </div>
    </div>
  );
};

export default StudyCard;