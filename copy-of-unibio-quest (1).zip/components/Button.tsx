import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'outline' | 'ghost';
  fullWidth?: boolean;
}

const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  fullWidth = false, 
  className = '', 
  ...props 
}) => {
  const baseStyle = "font-bold py-3 px-4 rounded-xl transition-all transform active:translate-y-1 active:border-b-0 uppercase tracking-widest text-sm sm:text-base";
  
  const variants = {
    primary: "bg-duo-green border-b-4 border-duo-green-dark text-white hover:bg-green-500",
    secondary: "bg-duo-blue border-b-4 border-duo-blue-dark text-white hover:bg-sky-400",
    danger: "bg-duo-red border-b-4 border-duo-red-dark text-white hover:bg-red-400",
    outline: "bg-white dark:bg-gray-800 border-2 border-b-4 border-duo-gray dark:border-gray-600 text-duo-green-dark dark:text-green-400 hover:bg-gray-50 dark:hover:bg-gray-700",
    ghost: "bg-transparent text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 border-none active:translate-y-0"
  };

  const widthClass = fullWidth ? 'w-full' : '';

  return (
    <button 
      className={`${baseStyle} ${variants[variant]} ${widthClass} ${className}`} 
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;