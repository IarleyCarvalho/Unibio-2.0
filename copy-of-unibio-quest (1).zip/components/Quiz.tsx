import React, { useState } from 'react';
import { Lesson } from '../types';
import Button from './Button';
import { CheckCircle, XCircle, BookOpen, X } from 'lucide-react';

interface QuizProps {
  lesson: Lesson;
  onComplete: (score: number) => void;
  onLoseHeart: () => void;
  hearts: number;
  onBack: () => void;
}

const Quiz: React.FC<QuizProps> = ({ lesson, onComplete, onLoseHeart, hearts, onBack }) => {
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [status, setStatus] = useState<'idle' | 'correct' | 'wrong'>('idle');
  const [correctCount, setCorrectCount] = useState(0);

  const question = lesson.questions[currentQIndex];

  const handleCheck = () => {
    if (selectedOption === null) return;

    if (selectedOption === question.correctAnswer) {
      setStatus('correct');
      setCorrectCount(prev => prev + 1);
    } else {
      setStatus('wrong');
      onLoseHeart();
    }
  };

  const handleNext = () => {
    if (hearts <= 0 && status === 'wrong') {
        onComplete(correctCount); 
        return;
    }

    if (currentQIndex < lesson.questions.length - 1) {
      setCurrentQIndex(prev => prev + 1);
      setSelectedOption(null);
      setStatus('idle');
    } else {
      onComplete(correctCount + (status === 'correct' ? 1 : 0));
    }
  };

  const progress = ((currentQIndex + (status !== 'idle' ? 1 : 0)) / lesson.questions.length) * 100;

  if (hearts <= 0 && status === 'idle') {
      return (
          <div className="flex flex-col items-center justify-center h-full pt-20 px-6 text-center bg-white dark:bg-gray-900">
              <div className="text-6xl mb-4">💔</div>
              <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">Suas vidas acabaram!</h2>
              <p className="text-gray-500 dark:text-gray-400 mb-8">Revise a teoria e tente novamente.</p>
              <Button fullWidth variant="secondary" onClick={() => onComplete(0)}>VOLTAR AO MAPA</Button>
          </div>
      )
  }

  return (
    <div className="flex flex-col h-full pt-16 pb-6 px-4 max-w-lg mx-auto w-full bg-white dark:bg-gray-900 transition-colors">
      
      {/* Header with Back Button and Progress */}
      <div className="flex items-center w-full mb-6 mt-2">
        <button 
            onClick={onBack}
            className="mr-4 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300 transition-colors"
            aria-label="Sair"
        >
            <X className="w-6 h-6" />
        </button>
        
        <div className="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-4 relative">
            <div 
                className="bg-duo-green h-4 rounded-full transition-all duration-500 ease-out"
                style={{ width: `${progress}%` }}
            >
                <div className="absolute top-1 right-2 bg-white/30 w-full h-1 rounded-full"></div>
            </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar pb-20">
        <h2 className="text-xl font-bold text-gray-700 dark:text-gray-200 mb-6">{question.text}</h2>

        <div className="space-y-3">
          {question.options.map((opt, idx) => {
            let btnVariant: 'outline' | 'primary' | 'danger' | 'ghost' | 'secondary' = 'outline';
            
            if (status === 'idle') {
                btnVariant = selectedOption === idx ? 'secondary' : 'outline';
            } else if (status === 'correct') {
                if (idx === question.correctAnswer) btnVariant = 'primary';
                else btnVariant = 'ghost'; 
            } else if (status === 'wrong') {
                if (idx === selectedOption) btnVariant = 'danger';
                else if (idx === question.correctAnswer) btnVariant = 'primary'; 
                else btnVariant = 'ghost';
            }

            return (
              <button
                key={idx}
                onClick={() => status === 'idle' && setSelectedOption(idx)}
                disabled={status !== 'idle'}
                className={`w-full p-4 rounded-xl border-2 text-left font-semibold transition-all
                  ${btnVariant === 'outline' ? 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200' : ''}
                  ${btnVariant === 'secondary' ? 'bg-sky-100 dark:bg-sky-900 border-sky-400 text-sky-700 dark:text-sky-300' : ''}
                  ${btnVariant === 'primary' ? 'bg-green-100 dark:bg-green-900 border-green-500 text-green-700 dark:text-green-300' : ''}
                  ${btnVariant === 'danger' ? 'bg-red-100 dark:bg-red-900 border-red-500 text-red-700 dark:text-red-300' : ''}
                  ${btnVariant === 'ghost' ? 'bg-transparent border-transparent text-gray-300 dark:text-gray-600 opacity-50' : ''}
                `}
              >
                <div className="flex items-center">
                    <span className="w-6 h-6 border-2 border-current rounded-md flex items-center justify-center mr-3 text-sm">
                        {String.fromCharCode(65 + idx)}
                    </span>
                    {opt}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className={`fixed bottom-0 left-0 right-0 p-4 border-t-2 z-20 transition-transform duration-300
        ${status === 'idle' ? 'translate-y-full' : 'translate-y-0'}
        ${status === 'correct' ? 'bg-green-100 dark:bg-green-900 border-green-200 dark:border-green-800' : 'bg-red-100 dark:bg-red-900 border-red-200 dark:border-red-800'}
      `}>
         <div className="max-w-lg mx-auto w-full">
            <div className="flex items-start mb-4">
                <div className="mr-3 mt-1">
                    {status === 'correct' ? <CheckCircle className="text-green-600 dark:text-green-400 w-8 h-8" /> : <XCircle className="text-red-600 dark:text-red-400 w-8 h-8" />}
                </div>
                <div>
                    <h3 className={`font-bold text-lg ${status === 'correct' ? 'text-green-800 dark:text-green-200' : 'text-red-800 dark:text-red-200'}`}>
                        {status === 'correct' ? 'Correto!' : 'Incorreto'}
                    </h3>
                    <p className={`text-sm mt-1 ${status === 'correct' ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300'}`}>
                        {question.explanation}
                    </p>
                     <p className="text-xs mt-2 font-semibold opacity-70 flex items-center dark:text-gray-300">
                        <BookOpen className="w-3 h-3 mr-1" /> Fonte: {question.source}
                    </p>
                </div>
            </div>
            <Button 
                fullWidth 
                variant={status === 'correct' ? 'primary' : 'danger'}
                onClick={handleNext}
            >
                CONTINUAR
            </Button>
         </div>
      </div>

      {status === 'idle' && (
          <div className="fixed bottom-0 left-0 right-0 p-4 border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900">
              <div className="max-w-lg mx-auto w-full">
                <Button 
                    fullWidth 
                    variant={selectedOption !== null ? 'primary' : 'ghost'} 
                    disabled={selectedOption === null}
                    onClick={handleCheck}
                    className={selectedOption === null ? 'bg-gray-200 dark:bg-gray-800 text-gray-400 dark:text-gray-600 cursor-not-allowed border-none' : ''}
                >
                    VERIFICAR
                </Button>
              </div>
          </div>
      )}
    </div>
  );
};

export default Quiz;