import React from 'react';
import { Heart, Zap, Flame } from 'lucide-react';
import { UserProgress } from '../types';

interface TopBarProps {
  progress: UserProgress;
  trackName: string;
}

const TopBar: React.FC<TopBarProps> = ({ progress, trackName }) => {
  return (
    <div className="fixed top-0 left-0 right-0 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 z-10 h-16 flex items-center justify-between px-4 max-w-lg mx-auto w-full transition-colors">
      <div className="flex items-center space-x-4 w-full justify-between">
         {/* Track Name */}
         <div className="font-bold text-gray-400 uppercase text-xs sm:text-sm tracking-wide hidden sm:block">
            {trackName}
         </div>

        <div className="flex items-center space-x-6 mx-auto sm:mx-0">
            {/* Streak */}
            <div className="flex items-center text-duo-yellow-dark font-bold">
            <Flame className="w-5 h-5 mr-1 fill-current" />
            <span>{progress.streak}</span>
            </div>

            {/* XP */}
            <div className="flex items-center text-duo-blue font-bold">
            <Zap className="w-5 h-5 mr-1 fill-current" />
            <span>{progress.xp}</span>
            </div>

            {/* Hearts */}
            <div className="flex items-center text-duo-red font-bold">
            <Heart className="w-5 h-5 mr-1 fill-current" />
            <span>{progress.hearts}</span>
            </div>
        </div>
      </div>
    </div>
  );
};

export default TopBar;