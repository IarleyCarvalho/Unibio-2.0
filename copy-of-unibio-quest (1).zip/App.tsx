import React, { useState, useEffect } from 'react';
import { AppState, UserProgress, Track } from './types';
import { biossistemasData, processosData } from './data';
import TopBar from './components/TopBar';
import Button from './components/Button';
import StudyCard from './components/StudyCard';
import Quiz from './components/Quiz';
import { 
  Book, 
  GraduationCap, 
  Settings, 
  Check, 
  RefreshCw, 
  BookOpen, 
  Moon, 
  Sun, 
  User, 
  Cloud, 
  Trophy, 
  Medal,
  Loader2 
} from 'lucide-react';

const INITIAL_PROGRESS: UserProgress = {
  xp: 0,
  hearts: 5,
  completedLessons: [],
  streak: 0,
  lastLoginDate: '',
  darkMode: false,
  userName: 'Estudante',
  defaultTrack: 'biossistemas'
};

const App: React.FC = () => {
  const [progress, setProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem('unibio_progress');
    return saved ? JSON.parse(saved) : INITIAL_PROGRESS;
  });

  const [state, setState] = useState<AppState>({
    currentTab: 'learn',
    currentTrack: progress.defaultTrack || 'biossistemas',
    activeLessonId: null,
    lessonMode: null,
  });

  // UI States for settings
  const [isSaving, setIsSaving] = useState(false);
  const [showSaveSuccess, setShowSaveSuccess] = useState(false);

  // Apply preferences on mount/update
  useEffect(() => {
    localStorage.setItem('unibio_progress', JSON.stringify(progress));
    
    // Apply Dark Mode
    if (progress.darkMode) {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark');
    }
  }, [progress]);

  // Streak Logic
  useEffect(() => {
    const today = new Date().toDateString();
    if (progress.lastLoginDate !== today) {
       setProgress(prev => ({...prev, lastLoginDate: today}));
    }
  }, []);

  const resetProgress = () => {
      if(confirm('Tem certeza? Todo o seu XP e progresso será apagado.')) {
        setProgress(INITIAL_PROGRESS);
        location.reload();
      }
  };

  const toggleDarkMode = () => {
      setProgress(prev => ({ ...prev, darkMode: !prev.darkMode }));
  };

  const saveToCloud = () => {
      setIsSaving(true);
      setShowSaveSuccess(false);
      
      // Simulate network request to Firebase
      setTimeout(() => {
          setIsSaving(false);
          setShowSaveSuccess(true);
          
          // Hide success message after 3 seconds
          setTimeout(() => {
              setShowSaveSuccess(false);
          }, 3000);
      }, 1500);
  };

  // Mock Leaderboard Generator
  const getLeaderboard = () => {
      const mockUsers = [
          { name: 'Ana Silva', xp: 1250 },
          { name: 'João Santos', xp: 980 },
          { name: 'Beatriz Costa', xp: 850 },
          { name: 'Carlos Oliveira', xp: 600 },
          { name: 'Mariana Lima', xp: 450 }
      ];
      
      // Add current user and sort
      const allUsers = [...mockUsers, { name: `${progress.userName} (Você)`, xp: progress.xp }];
      return allUsers.sort((a, b) => b.xp - a.xp).slice(0, 5); // Top 5
  };

  // Lesson Logic
  const activeData = state.currentTrack === 'biossistemas' ? biossistemasData : processosData;
  const activeLesson = activeData.find(l => l.id === state.activeLessonId);

  const startLesson = (lessonId: string) => {
    if (progress.hearts <= 0) {
      alert("Você precisa recuperar vidas antes de estudar! (Dica: Vá nas configurações e 'Atualize o App' para resetar rapidinho 😉)");
      return;
    }
    setState(prev => ({ ...prev, activeLessonId: lessonId, lessonMode: 'theory' }));
  };

  const exitLesson = () => {
    // If they leave early, they don't get XP, but we also don't penalize.
    setState(prev => ({ ...prev, activeLessonId: null, lessonMode: null }));
  };

  const finishTheory = () => {
    setState(prev => ({ ...prev, lessonMode: 'quiz' }));
  };

  const finishQuiz = (correctCount: number) => {
      if (state.activeLessonId && correctCount >= 3) {
         if (!progress.completedLessons.includes(state.activeLessonId)) {
             setProgress(prev => ({
                 ...prev,
                 completedLessons: [...prev.completedLessons, state.activeLessonId!],
                 xp: prev.xp + 20 + (correctCount * 2)
             }));
         } else {
             setProgress(prev => ({
                 ...prev,
                 xp: prev.xp + 5
             }));
         }
      }
      setState(prev => ({ ...prev, activeLessonId: null, lessonMode: null }));
  };

  const loseHeart = () => {
      setProgress(prev => ({ ...prev, hearts: Math.max(0, prev.hearts - 1) }));
  };

  // --- RENDERS ---

  const renderDashboard = () => (
    <div className="pt-20 pb-24 px-4 max-w-lg mx-auto w-full space-y-6">
        {/* Track Switcher */}
        <div className="flex bg-gray-200 dark:bg-gray-800 p-1 rounded-xl mb-6">
            <button 
                onClick={() => setState(prev => ({...prev, currentTrack: 'biossistemas'}))}
                className={`flex-1 py-2 text-sm font-bold rounded-lg transition-colors ${state.currentTrack === 'biossistemas' ? 'bg-white dark:bg-gray-700 shadow text-duo-green-dark dark:text-green-400' : 'text-gray-500'}`}
            >
                BIOSSISTEMAS
            </button>
            <button 
                 onClick={() => setState(prev => ({...prev, currentTrack: 'processos'}))}
                 className={`flex-1 py-2 text-sm font-bold rounded-lg transition-colors ${state.currentTrack === 'processos' ? 'bg-white dark:bg-gray-700 shadow text-duo-blue-dark dark:text-sky-400' : 'text-gray-500'}`}
            >
                PROCESSOS
            </button>
        </div>

        {/* Grid of Lessons */}
        <div className="grid grid-cols-1 gap-4">
            {activeData.map((lesson) => {
                const isCompleted = progress.completedLessons.includes(lesson.id);
                return (
                    <div 
                        key={lesson.id} 
                        className={`flex items-center p-4 rounded-2xl border-2 border-b-4 cursor-pointer transition-all active:border-b-2 active:translate-y-1 bg-white dark:bg-gray-800 dark:border-gray-700
                            ${isCompleted ? 'border-duo-yellow-dark' : 'border-gray-200 hover:bg-gray-50 dark:hover:bg-gray-750'}
                        `}
                        onClick={() => startLesson(lesson.id)}
                    >
                         <div className="text-4xl mr-4">{lesson.icon}</div>
                         <div className="flex-1">
                             <h3 className="font-bold text-gray-800 dark:text-gray-200">{lesson.system}</h3>
                             <p className="text-sm text-gray-500 dark:text-gray-400">{lesson.title}</p>
                         </div>
                         {isCompleted && <Check className="text-duo-yellow-dark w-6 h-6" />}
                    </div>
                );
            })}
        </div>
    </div>
  );

  const renderLibrary = () => (
      <div className="pt-20 px-6 max-w-lg mx-auto text-center pb-24">
          <h2 className="text-2xl font-bold text-gray-700 dark:text-gray-200 mb-4">Biblioteca Oficial</h2>
          <p className="text-gray-500 dark:text-gray-400 mb-8">Bibliografia utilizada nas questões:</p>
          
          <ul className="text-left space-y-4">
              {[
                  "Guyton & Hall - Tratado de Fisiologia Médica",
                  "Tortora & Derrickson - Princípios de Anatomia e Fisiologia",
                  "Netter - Atlas de Anatomia Humana",
                  "Alberts - Biologia Molecular da Célula",
                  "Junqueira & Carneiro - Histologia Básica",
                  "Abbas - Imunologia Celular e Molecular",
                  "Angelo Machado - Neuroanatomia Funcional",
                  "McArdle - Fisiologia do Exercício"
              ].map((book, i) => (
                  <li key={i} className="bg-white dark:bg-gray-800 p-4 rounded-xl border-2 border-gray-200 dark:border-gray-700 flex items-center">
                      <BookOpen className="text-duo-blue mr-3 flex-shrink-0" />
                      <span className="font-semibold text-gray-700 dark:text-gray-300 text-sm">{book}</span>
                  </li>
              ))}
          </ul>
      </div>
  );

  const renderSettings = () => {
      const leaderboard = getLeaderboard();
      
      return (
      <div className="pt-20 px-6 max-w-lg mx-auto pb-24">
          <h2 className="text-2xl font-bold text-gray-700 dark:text-gray-200 mb-6">Configurações</h2>
          
          {/* PROFILE SECTION */}
          <div className="mb-8">
              <h3 className="text-gray-400 font-bold uppercase tracking-widest text-xs mb-4 border-b border-gray-200 dark:border-gray-700 pb-2">Perfil e Dados</h3>
              
              <div className="mb-4">
                  <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">Seu Nome (Ranking)</label>
                  <div className="flex gap-2">
                    <input 
                        type="text" 
                        value={progress.userName}
                        onChange={(e) => setProgress(prev => ({...prev, userName: e.target.value}))}
                        className="flex-1 p-3 rounded-xl border-2 border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 dark:text-white focus:outline-none focus:border-duo-blue"
                    />
                  </div>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                  <Button variant="secondary" onClick={saveToCloud} className="text-sm" disabled={isSaving}>
                      {isSaving ? <Loader2 className="animate-spin w-5 h-5 mx-auto"/> : <><Cloud className="inline mr-2 w-4 h-4" /> SALVAR</>}
                  </Button>
                  <Button variant="danger" onClick={resetProgress} className="text-sm">
                      RESETAR
                  </Button>
              </div>

              <div className={`transition-all duration-300 overflow-hidden ${showSaveSuccess ? 'max-h-20 opacity-100 mt-2' : 'max-h-0 opacity-0'}`}>
                  <div className="bg-green-100 dark:bg-green-900 border border-green-200 dark:border-green-800 text-green-700 dark:text-green-300 p-3 rounded-xl flex items-center justify-center text-sm font-bold shadow-sm">
                      <Check className="w-5 h-5 mr-2" />
                      Sincronizado com Firebase!
                  </div>
              </div>
          </div>

          {/* LEADERBOARD SECTION */}
          <div className="mb-8">
               <h3 className="text-gray-400 font-bold uppercase tracking-widest text-xs mb-4 border-b border-gray-200 dark:border-gray-700 pb-2 flex items-center">
                   <Trophy className="w-4 h-4 mr-1 text-duo-yellow-dark" /> Ranking Geral
               </h3>
               <div className="bg-white dark:bg-gray-800 rounded-xl border-2 border-gray-200 dark:border-gray-700 overflow-hidden">
                   {leaderboard.map((user, idx) => (
                       <div key={idx} className={`p-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-700 last:border-0 ${user.name.includes('(Você)') ? 'bg-yellow-50 dark:bg-gray-700' : ''}`}>
                           <div className="flex items-center">
                               <span className={`w-6 font-bold mr-3 text-center ${idx < 3 ? 'text-duo-yellow-dark text-xl' : 'text-gray-400'}`}>
                                   {idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : idx + 1}
                               </span>
                               <span className={`font-semibold ${user.name.includes('(Você)') ? 'text-duo-blue' : 'text-gray-700 dark:text-gray-300'}`}>
                                   {user.name}
                               </span>
                           </div>
                           <span className="font-bold text-duo-yellow-dark">{user.xp} XP</span>
                       </div>
                   ))}
               </div>
          </div>

          {/* PREFERENCES SECTION */}
          <div className="mb-8">
              <h3 className="text-gray-400 font-bold uppercase tracking-widest text-xs mb-4 border-b border-gray-200 dark:border-gray-700 pb-2">Preferências</h3>
              
              <div className="space-y-3">
                <Button fullWidth variant="outline" onClick={toggleDarkMode}>
                    {progress.darkMode ? <Sun className="inline mr-2 w-5 h-5" /> : <Moon className="inline mr-2 w-5 h-5" />}
                    {progress.darkMode ? 'MODO CLARO' : 'MODO NOTURNO'}
                </Button>

                <div className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-xl">
                    <span className="font-bold text-gray-700 dark:text-gray-300 text-sm ml-2">Trilha Padrão ao Iniciar:</span>
                    <select 
                        value={progress.defaultTrack}
                        onChange={(e) => setProgress(prev => ({...prev, defaultTrack: e.target.value as Track}))}
                        className="p-2 rounded-lg bg-gray-100 dark:bg-gray-900 border-none font-bold text-sm dark:text-white focus:outline-none"
                    >
                        <option value="biossistemas">Biossistemas</option>
                        <option value="processos">Processos</option>
                    </select>
                </div>
              </div>
          </div>

          {/* ABOUT SECTION */}
          <div className="p-6 bg-gray-100 dark:bg-gray-800 rounded-2xl border-2 border-gray-200 dark:border-gray-700 text-center">
              <h3 className="text-gray-400 font-bold uppercase tracking-widest text-xs mb-2">Sobre</h3>
              <p className="text-gray-600 dark:text-gray-300 font-semibold">© UniBio Quest - Edição UNIFACS</p>
              
              <Button variant="ghost" className="my-4 text-xs" onClick={() => setState(prev => ({...prev, currentTab: 'library'}))}>
                  <Book className="inline w-4 h-4 mr-1" /> VER BIBLIOGRAFIA COMPLETA
              </Button>

              <div className="text-gray-500 dark:text-gray-400 text-sm mt-2 italic border-t border-gray-300 dark:border-gray-600 pt-4">
                  "O colega Iarley sofreu tentando chegar no app perfeito, foram vários prompts e muitas noites sem dormir para você não precisar sofrer nas provas! 😂"
              </div>
              <p className="text-xs text-gray-400 mt-2">v1.0.0</p>
          </div>
      </div>
  )};

  // --- MAIN RENDER LOGIC ---

  if (state.lessonMode === 'theory' && activeLesson) {
      return <StudyCard lesson={activeLesson} onComplete={finishTheory} onBack={exitLesson} />;
  }

  if (state.lessonMode === 'quiz' && activeLesson) {
      return (
        <Quiz 
            lesson={activeLesson} 
            hearts={progress.hearts}
            onComplete={finishQuiz} 
            onLoseHeart={loseHeart}
            onBack={exitLesson}
        />
      );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 sm:bg-gray-100 sm:dark:bg-black transition-colors font-sans">
        <TopBar progress={progress} trackName={state.currentTrack === 'biossistemas' ? 'Biossistemas' : 'Proc. Biológicos'} />
        
        <div className="bg-white dark:bg-gray-900 min-h-screen sm:min-h-0 sm:mx-auto sm:max-w-lg sm:border-x sm:border-gray-200 sm:dark:border-gray-800 relative pb-20 transition-colors">
             {state.currentTab === 'learn' && renderDashboard()}
             {state.currentTab === 'library' && renderLibrary()}
             {state.currentTab === 'settings' && renderSettings()}
        </div>

        <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 h-20 px-4 max-w-lg mx-auto w-full z-20 transition-colors">
            <div className="flex justify-around items-center h-full">
                <button 
                    onClick={() => setState(prev => ({...prev, currentTab: 'learn'}))}
                    className={`flex flex-col items-center justify-center w-20 h-full ${state.currentTab === 'learn' ? 'text-duo-green' : 'text-gray-400 dark:text-gray-600 hover:text-gray-600 dark:hover:text-gray-400'}`}
                >
                    <GraduationCap className={`w-8 h-8 ${state.currentTab === 'learn' ? 'fill-current' : ''}`} strokeWidth={state.currentTab === 'learn' ? 0 : 2} />
                    <span className="text-xs font-bold uppercase mt-1">Aprender</span>
                </button>

                <button 
                    onClick={() => setState(prev => ({...prev, currentTab: 'library'}))}
                    className={`flex flex-col items-center justify-center w-20 h-full ${state.currentTab === 'library' ? 'text-duo-blue' : 'text-gray-400 dark:text-gray-600 hover:text-gray-600 dark:hover:text-gray-400'}`}
                >
                    <Book className={`w-8 h-8 ${state.currentTab === 'library' ? 'fill-current' : ''}`} strokeWidth={state.currentTab === 'library' ? 0 : 2} />
                    <span className="text-xs font-bold uppercase mt-1">Biblioteca</span>
                </button>

                <button 
                    onClick={() => setState(prev => ({...prev, currentTab: 'settings'}))}
                    className={`flex flex-col items-center justify-center w-20 h-full ${state.currentTab === 'settings' ? 'text-duo-blue' : 'text-gray-400 dark:text-gray-600 hover:text-gray-600 dark:hover:text-gray-400'}`}
                >
                    <Settings className={`w-8 h-8 ${state.currentTab === 'settings' ? 'fill-current' : ''}`} strokeWidth={state.currentTab === 'settings' ? 0 : 2} />
                    <span className="text-xs font-bold uppercase mt-1">Config</span>
                </button>
            </div>
        </div>
    </div>
  );
};

export default App;